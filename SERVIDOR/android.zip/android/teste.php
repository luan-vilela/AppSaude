<!DOCTYPE html>
<html>
<head>
	<title>teste</title>
</head>
<body>

	<form method="POST" action="serverContent.php">
		<input type="text" name="idRegistro" placeholder="nome"><br>
		<input type="text" name="email" placeholder="email"><br>
		<input type="hidden" name="key" value="123"><br>
		<input type="submit" value="enviar	">
		
	</form>

</body>
</html>